<!-- Stylesheets -->
<link href="<?php echo e(asset('dist-front/css/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('dist-front/css/style.css')); ?>" rel="stylesheet">
<?php if(session('sess_lang_direction') == 'Right to Left (RTL)'): ?>
<link href="<?php echo e(asset('dist-front/css/rtl.css')); ?>" rel="stylesheet">
<?php endif; ?>
<style>
    .preloader:after {
        background-image: url(<?php echo e(asset('uploads/'.$global_setting->favicon)); ?>);
    }
    .dark-layout .preloader:after {
        background-image: url(<?php echo e(asset('uploads/'.$global_setting->logo)); ?>);
    }
</style><?php /**PATH /opt/homebrew/var/www/phpscriptpoint/desix/desix/cms/resources/views/front/layouts/styles.blade.php ENDPATH**/ ?>